<?php

namespace app\migrations;

class m0002_something
{
    public function up()
    {
        echo "Applying migration  {" . __CLASS__ . "}\n";
    }

    public function down()
    {
        echo "Down migration  {" . __CLASS__ . "}\n";
    }
}
