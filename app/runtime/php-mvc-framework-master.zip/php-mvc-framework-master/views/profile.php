<?php
/** @var $this \thecodeholic\phpmvc\View */

$this->title = 'Profile';
?>

<h1>Profile page</h1>