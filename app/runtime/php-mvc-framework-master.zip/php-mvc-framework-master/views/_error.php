<?php
/**
 * User: TheCodeholic
 * Date: 7/11/2020
 * Time: 10:12 AM
 */
/** @var $exception \Exception */
?>

<h3><?php echo $exception->getCode() ?> - <?php echo $exception->getMessage() ?></h3>
