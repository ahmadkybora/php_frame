<?php

use Core\App;

require_once __DIR__ . '/../vendor/autoload.php';

new App;
