<?php

namespace Core\Console;

class Color
{
    public static $TEXT_ERROR = "\033[31m";
    public static $TEXT_ORANG = "\033[0;33m";
    public static $TEXT_GREEN = "\033[1;32m";
    public static $BACK_ERROR = "\033[41m";
    public static $END = "\033[0m";
}
